# module for tei dict converter
#

package teihandler;

use dict;

sub set_file_name {
    my ($self, $fname) = @_;
    $file_name = $fname;
}

sub new {
    my ($type) = @_;
    $file_name =~ s/^(\w*\/)+//g;         
    $file_name =~ s/(\S*)\.\w*/\1/;
    dict->open_dict($file_name);
    return bless {}, $type;
}

sub start_document {
}

sub characters {
    my ($self, $element) = @_;

    $tmp =   $element->{Data};
    chomp $tmp;
     $tmp  =~ s/\s+$//;
     $char .= $tmp ;
     $char .= "\n" if ( $current eq "DEF");
}

sub start_element {
    my ($self, $element) = @_;
    $current = $element->{Name};
    %elements = ();
}



sub end_element {
    my ($self, $element) = @_;
  
  
  dict::write_headword($char, 1)if ($element->{Name} eq "ORTH");

  dict::write_text(" [$char]") if ($element->{Name} eq "PRON");
  dict::write_text(", male ") if (($element->{Name} eq "GEN") && ($char eq "m"));
  dict::write_text(", female ") if (($element->{Name} eq "GEN") && ($char eq "f"));
  dict::write_text(", nutral ") if (($element->{Name} eq "GEN") && ($char eq "n"));
  dict::write_text(", male & female ") if (($element->{Name} eq "GEN") && ($char eq "m;f"));
  dict::write_text(", plural") if (($element->{Name} eq "NUM") && ($char eq "pl"));
  dict::write_text(", noun") if (($element->{Name} eq "POS") && ($char eq "n"));
  dict::write_text("\n  $char") if ($element->{Name} eq "DEF");
  dict::write_text("\n  $char") if ($element->{Name} eq "TRANS");
    
    $char = "";
}

1;

