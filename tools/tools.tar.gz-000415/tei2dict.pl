#!/usr/bin/perl
# 

use XML::ESISParser;
use XML::Handler::Sample;

use teihandler;


sub dump_header {
# H.Ey - 3. Apr. 2000 
# complete dump_header function!
    write_headword ("00-test-1");
    write_text ("nur ein erster Test1");
    write_headword ("00-test-2");
    write_text ("nur ein erster Test2");
    write_headword ("00-test-3");
    write_text ("nur ein erster Test3");
    write_headword ("00-test-4", 1);
    write_text ("nur ein erster Test4");
}


sub dump_words {
# H.Ey - 3. Apr. 2000
# complete dump_words function!
    write_headword("", 0);
}



push (@additional_args, IsSGML => 1);


#if ($#ARGV != 0) {
#    die "usage: esis-test FILE\n";
#}
$file = shift @ARGV;


$input = $file ;

die "Can�t finde file \"$input\"" unless -f $input;


# open_dict($file);

# open INPUT, "<$input";




$my_handler = XML::Handler::Sample->new;

teihandler->set_file_name($file);

XML::ESISParser->new->parse(Source => { SystemId => $input },
                            Handler => teihandler->new,
                            @additional_args);






#dump_header();
#dump_words();

# that�s it
